const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');

const qrcode = require('qrcode-terminal');
const pino = require('pino');
const fs = require('fs');
const path = require('path');

/* ================= CONFIG ================= */

const AUTO_REPLY =
  'This phone number is temporarily unavailable on WhatsApp. Your message has been received and will be seen after a few days.';

const OWNER_NUMBER = '918770097544';   // full number with country code
const AUTH_DIR    = path.join(__dirname, 'auth_info');
const LOG_DIR     = path.join(__dirname, 'logs');
const LOG_FILE    = path.join(LOG_DIR, 'bot.log');
const BOT_STATE_FILE = path.join(LOG_DIR, 'bot_state.json');

/* ================= SETUP ================= */

if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR);

function log(text) {
  const line = `[${new Date().toLocaleString()}] ${text}\n`;
  try { fs.appendFileSync(LOG_FILE, line); } catch (_) {}
  console.log(text);
}

/* ================= STATE ================= */

function getBotState() {
  try {
    if (fs.existsSync(BOT_STATE_FILE))
      return JSON.parse(fs.readFileSync(BOT_STATE_FILE, 'utf8'));
  } catch (_) {}
  const s = { paused: false };
  try { fs.writeFileSync(BOT_STATE_FILE, JSON.stringify(s)); } catch (_) {}
  return s;
}

function setBotState(paused) {
  botState.paused = paused;
  try { fs.writeFileSync(BOT_STATE_FILE, JSON.stringify(botState)); } catch (_) {}
}

let botState = getBotState();
let qrShown = false;
let isReconnecting = false;

let selfJidNumber = null;   // e.g. '918770097544'  (from sock.user.id)
let selfJidLid    = null;   // e.g. '222191710912547' (from sock.user.lid)

const BOT_START_TIME = Date.now();

function bareId(jid) {
  return (jid || '').split('@')[0].split(':')[0];
}

function isSelfChat(jid) {
  if (!jid) return false;
  const id = bareId(jid);
  if (selfJidNumber && id === selfJidNumber) return true;
  if (selfJidLid    && id === selfJidLid)    return true;
  return false;
}

function extractText(msg) {
  const m = msg.message;
  if (!m) return '';
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.documentMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    m.templateButtonReplyMessage?.selectedId ||
    ''
  );
}


async function createWhatsAppClient() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      auth: state,
      logger: pino({ level: 'silent' }),
      version,
      browser: ['Windows', 'Chrome', '122.0.0'],
      markOnlineOnConnect: false,
      syncFullHistory: false
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', ({ connection, qr, lastDisconnect }) => {
      if (qr && !qrShown) {
        qrShown = true;
        console.log('\n📱 Scan QR code\n');
        qrcode.generate(qr, { small: true });
      }

      if (connection === 'open') {
        qrShown = false;
        isReconnecting = false;
        selfJidNumber = bareId(sock.user?.id  || '') || OWNER_NUMBER;
        selfJidLid    = bareId(sock.user?.lid || '') || null;
        log(`✅ Connected`);
      }

      if (connection === 'close') {
        const code = lastDisconnect?.error?.output?.statusCode;
        const loggedOut = code === DisconnectReason.loggedOut;

        if (loggedOut) {
          log('🚪 Logged out — restart and rescan QR');
          try { fs.rmSync(AUTH_DIR, { recursive: true, force: true }); } catch (_) {}
          return;
        }

        if (!isReconnecting) {
          isReconnecting = true;
          log('🔄 Reconnecting...');
          setTimeout(createWhatsAppClient, 3000);
        }
      }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
      for (const msg of messages) {
        try {
          if (!msg?.message) continue;

          const jid = msg.key.remoteJid || '';
          if (!jid) continue;

          // Skip groups, status broadcasts, newsletters
          if (
            jid.endsWith('@g.us') ||
            jid === 'status@broadcast' ||
            jid.endsWith('@newsletter')
          ) continue;

          // Ignore old history replayed on reconnect
          const msgTs = Number(msg.messageTimestamp || 0) * 1000;
          if (msgTs > 0 && msgTs < BOT_START_TIME - 30_000) continue;

          const fromMe    = msg.key.fromMe;
          const selfChat  = isSelfChat(jid);
          const text      = extractText(msg).trim();
          if (selfChat) {
            const cmd = text.toUpperCase();

            if (cmd === 'PAUSE') {
              setBotState(true);
              log('⏸ Bot paused');
              sock.sendMessage(jid, { text: '⏸ Bot paused. Send *START* to resume.' }).catch(() => {});

            } else if (cmd === 'START') {
              setBotState(false);
              log('▶ Bot resumed');
              sock.sendMessage(jid, { text: '▶ Bot resumed.' }).catch(() => {});

            } else if (cmd === 'STATUS') {
              sock.sendMessage(jid, {
                text: `Status: ${botState.paused ? '⏸ Paused' : '▶ Running'}`
              }).catch(() => {});
            }

            continue; // never auto-reply in self-chat
          }

          // ── ALL OTHER CHATS ────────────────────────────────────────────────
          if (type !== 'notify') continue;
          if (fromMe) continue;

          if (botState.paused) continue;

          sock.sendMessage(jid, { text: AUTO_REPLY }).catch((e) => {
            log(`Send error: ${e.message}`);
          });

        } catch (err) {
          log(`Message handling error: ${err.message}`);
        }
      }
    });

  } catch (err) {
    log(`Client error: ${err.message}`);
    if (!isReconnecting) {
      isReconnecting = true;
      setTimeout(() => {
        isReconnecting = false;
        createWhatsAppClient();
      }, 5000);
    }
  }
}

createWhatsAppClient();

/* ================= CRASH GUARD ================= */

process.on('uncaughtException',  (err) => { log(`Uncaught: ${err.message}`); });
process.on('unhandledRejection', (err) => { log(`Rejection: ${err?.message || err}`); });